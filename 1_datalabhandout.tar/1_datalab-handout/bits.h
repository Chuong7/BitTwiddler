
int minusOne();
int test_minusOne();
int fitsShort(int);
int test_fitsShort(int);
int upperBits(int);
int test_upperBits(int);
int anyOddBit();
int test_anyOddBit();
int implication(int, int);
int test_implication(int, int);
int bitMask(int, int);
int test_bitMask(int, int);
